class Bubble {

  constructor(tempX, tempY, tempR) {
    this.x = tempX;
    this.y = tempY;
    this.r = tempR;
  }

  move() {
    this.x = this.x + random(-10, 10);
    this.y = this.y + random(-10, 10);
  }

  show() {

    noStroke();

    c.r = random(25, 0);
    c.g = random(155, 0);
    c.b = random(255, 0);
    c.t = random(5, 35);
    fill(c.r, c.g, c.b, c.t);

    ellipse(this.x, this.y, this.r, this.r);

  }

}